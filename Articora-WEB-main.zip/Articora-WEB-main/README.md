# Artícora-WEB
## Autores
- Joaquín Gutiérrez Díaz — 22300907
- Leonardo Serna Sánchez — 22300909
- David Israel Gómez Méndez — 22300926
## Materia 
- Programación Web I
- 7E1
- Paola Fernanda Ponce Villalvazo
## Actividad
- ### Examen práctico
- Propuesta con mínimo dos estilos
